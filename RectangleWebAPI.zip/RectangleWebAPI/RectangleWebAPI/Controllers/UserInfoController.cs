﻿using Microsoft.AspNetCore.Mvc;
using RectangleWebAPI.IServices;
using RectangleWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RectangleWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserInfoController : ControllerBase
    {
        private IUserInfoRepository _userInfoRepository;
        public UserInfoController(IUserInfoRepository userInfoRepository)
        {
            _userInfoRepository = userInfoRepository;
        }

        [HttpPost]
        [Route("authenticate")]
        public IActionResult Authenticate(AuthenticationModel model)
        {
            var user = _userInfoRepository.Authenticate(model.UserName, model.Password);

            if (user == null) return BadRequest("Not authorized");

            return Ok(user);
        }
    }
}
