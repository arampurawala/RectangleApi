﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RectangleWebAPI.Infrastructure;
using RectangleWebAPI.IServices;
using System.Collections.Generic;

namespace RectangleWebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RectangleController : ControllerBase
    {
        private readonly IRectangleRepository _rectangleRepository;
        private List<RectangleList> list;
        public RectangleController(IRectangleRepository rectangleRepository)
        {
            _rectangleRepository = rectangleRepository;
        }

        [Authorize]
        [HttpGet]
        [Route("search")]
        public IActionResult Search(float x, float y)
        {
            var rectangles = _rectangleRepository.Search(x, y);
            return rectangles.Count == 0 ? Ok("Point does not lie in the given set of rectangles") : Ok(rectangles);
        }
    }
}
