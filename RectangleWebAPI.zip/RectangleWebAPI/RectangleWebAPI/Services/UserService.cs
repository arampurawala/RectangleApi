﻿using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using RectangleWebAPI.Helper;
using RectangleWebAPI.IServices;
using RectangleWebAPI.Models;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace RectangleWebAPI.Services
{
    public class UserService : IUserInfoRepository
    {
        private List<UserInfo> users = new List<UserInfo>{
            new UserInfo
            {
                Id = Guid.NewGuid(),
                Username = "Test User",
                Password = "Test123"
            }};

        private readonly AppSettings _appSettings;

        public UserService(IOptions<AppSettings> appSettings)
        {
            _appSettings = appSettings.Value;
        }
        public UserInfo Authenticate(string username, string password)
        {
            var user = users.SingleOrDefault(a => a.Username == username && a.Password == password);

            if (user == null) return null;

            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
            var tokenDescription = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]{
                    new Claim(ClaimTypes.Name, user.Id.ToString())
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key),SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescription);
            user.Token = tokenHandler.WriteToken(token);

            return user;
        }
    }
}
