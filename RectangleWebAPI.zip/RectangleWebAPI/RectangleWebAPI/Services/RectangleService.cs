﻿using RectangleWebAPI.Infrastructure;
using RectangleWebAPI.IServices;
using RectangleWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;

namespace RectangleWebAPI.Services
{
    public class RectangleService : IRectangleRepository
    {
        private readonly AppDbContext context;
        public RectangleService(AppDbContext context)
        {
            this.context = context;
        }
        public List<RectangleList> GetRectangles()
        {
            var list = new List<RectangleList>();
            var rectangleCoordinates = new List<RectangleCoordinates>();
            rectangleCoordinates = context.Rectangles.Select(a => new RectangleCoordinates() { Id = a.Id, X1 = a.X1, X2 = a.X2, Y1 = a.Y1, Y2 = a.Y2 }).ToList();

            foreach(var coordinates in rectangleCoordinates)
            {
                var rectToAdd = new RectangleList();
                var x = (float)coordinates.X1;
                var y = (float)coordinates.Y1;
                var width = (float)Math.Abs(coordinates.X1 - coordinates.X2);
                var height = (float)Math.Abs(coordinates.Y1 - coordinates.Y2);

                RectangleF rect = new RectangleF(x,y,width,height);
                rectToAdd.Id = coordinates.Id;
                rectToAdd.Rectangle = rect;

                list.Add(rectToAdd);
            }

            return list;
        }
        public List<RectangleList> Search(float x, float y)
        {
            var rectangles = GetRectangles();
            var list = new List<RectangleList>();

            foreach (var rectangle in rectangles)
            {
                if (rectangle.Rectangle.Contains(x, y))
                    list.Add(rectangle);
            }

            return list;
        }
    }
}
