﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RectangleWebAPI.Migrations
{
    public partial class SeedData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Rectangles",
                columns: new[] { "Id", "X1", "X2", "Y1", "Y2" },
                values: new object[,]
                {
                    { 1, -13.24, -24.030000000000001, -24.82, -18.030000000000001 },
                    { 128, -12.85, -22.629999999999999, -10.67, -18.879999999999999 },
                    { 129, -29.399999999999999, -19.77, -18.890000000000001, -29.399999999999999 },
                    { 130, -17.670000000000002, -18.949999999999999, -30.370000000000001, -28.440000000000001 },
                    { 131, -20.140000000000001, -24.93, -20.390000000000001, -29.289999999999999 },
                    { 132, -26.609999999999999, -26.609999999999999, -26.300000000000001, -19.850000000000001 },
                    { 133, -10.380000000000001, -22.309999999999999, -20.100000000000001, -10.779999999999999 },
                    { 134, -17.800000000000001, -12.77, -18.280000000000001, -11.130000000000001 },
                    { 135, -30.18, -22.25, -22.75, -19.780000000000001 },
                    { 136, -25.390000000000001, -14.140000000000001, -28.07, -23.050000000000001 },
                    { 137, -16.93, -14.880000000000001, -30.34, -15.06 },
                    { 138, -22.510000000000002, -11.539999999999999, -12.970000000000001, -20.859999999999999 },
                    { 139, -23.440000000000001, -16.309999999999999, -25.66, -16.469999999999999 },
                    { 140, -17.34, -21.940000000000001, -12.52, -29.32 },
                    { 141, -28.77, -30.079999999999998, -15.01, -21.530000000000001 },
                    { 142, -12.529999999999999, -30.890000000000001, -11.08, -26.620000000000001 },
                    { 143, -11.49, -17.760000000000002, -30.219999999999999, -26.43 },
                    { 144, -27.199999999999999, -20.59, -13.050000000000001, -16.010000000000002 },
                    { 145, -27.870000000000001, -28.34, -22.359999999999999, -21.719999999999999 },
                    { 146, -27.27, -21.239999999999998, -28.329999999999998, -29.84 },
                    { 147, -19.34, -30.239999999999998, -18.34, -11.49 },
                    { 148, -18.109999999999999, -11.81, -24.789999999999999, -18.25 },
                    { 127, -24.93, -24.07, -18.920000000000002, -15.380000000000001 },
                    { 149, -19.73, -24.43, -22.010000000000002, -26.32 },
                    { 126, -10.4, -27.73, -20.23, -29.120000000000001 },
                    { 124, -24.82, -10.41, -30.940000000000001, -20.649999999999999 },
                    { 103, -18.27, -12.24, -23.890000000000001, -29.579999999999998 },
                    { 104, -30.280000000000001, -16.760000000000002, -11.56, -28.050000000000001 },
                    { 105, -11.390000000000001, -27.41, -18.079999999999998, -19.66 },
                    { 106, -12.33, -17.629999999999999, -26.050000000000001, -21.039999999999999 },
                    { 107, -12.94, -19.66, -14.539999999999999, -27.859999999999999 },
                    { 108, -24.949999999999999, -16.039999999999999, -11.49, -25.219999999999999 },
                    { 109, -14.73, -15.210000000000001, -10.869999999999999, -23.190000000000001 },
                    { 110, -13.710000000000001, -22.27, -17.16, -17.760000000000002 },
                    { 111, -17.699999999999999, -24.43, -25.039999999999999, -14.5 },
                    { 112, -13.470000000000001, -25.260000000000002, -21.800000000000001, -26.120000000000001 },
                    { 113, -17.489999999999998, -18.27, -13.19, -29.170000000000002 },
                    { 114, -15.699999999999999, -14.81, -10.529999999999999, -24.260000000000002 },
                    { 115, -30.43, -15.970000000000001, -28.449999999999999, -16.75 },
                    { 116, -17.82, -28.050000000000001, -25.629999999999999, -12.220000000000001 },
                    { 117, -10.75, -29.66, -24.850000000000001, -25.07 },
                    { 118, -15.890000000000001, -19.370000000000001, -24.34, -20.120000000000001 }
                });

            migrationBuilder.InsertData(
                table: "Rectangles",
                columns: new[] { "Id", "X1", "X2", "Y1", "Y2" },
                values: new object[,]
                {
                    { 119, -20.25, -10.32, -11.960000000000001, -18.899999999999999 },
                    { 120, -23.59, -21.550000000000001, -17.579999999999998, -18.68 },
                    { 121, -28.859999999999999, -19.41, -20.370000000000001, -16.68 },
                    { 122, -12.85, -13.31, -19.52, -30.920000000000002 },
                    { 123, -14.68, -17.600000000000001, -23.760000000000002, -28.73 },
                    { 125, -29.809999999999999, -22.809999999999999, -13.75, -14.800000000000001 },
                    { 102, -26.41, -22.350000000000001, -24.91, -19.57 },
                    { 150, -30.129999999999999, -16.530000000000001, -20.510000000000002, -17.039999999999999 },
                    { 152, -12.31, -17.550000000000001, -24.66, -12.85 },
                    { 178, -19.510000000000002, -18.420000000000002, -12.859999999999999, -16.140000000000001 },
                    { 179, -27.399999999999999, -12.619999999999999, -18.030000000000001, -23.100000000000001 },
                    { 180, -10.5, -20.16, -12.369999999999999, -19.870000000000001 },
                    { 181, -22.27, -11.56, -14.43, -10.18 },
                    { 182, -22.120000000000001, -27.050000000000001, -17.370000000000001, -13.449999999999999 },
                    { 183, -30.460000000000001, -14.01, -15.85, -29.66 },
                    { 184, -24.379999999999999, -23.539999999999999, -16.539999999999999, -19.890000000000001 },
                    { 185, -24.699999999999999, -18.489999999999998, -20.469999999999999, -18.760000000000002 },
                    { 186, -19.579999999999998, -13.06, -22.100000000000001, -12.41 },
                    { 187, -10.83, -22.219999999999999, -17.41, -30.18 },
                    { 188, -29.16, -18.84, -24.199999999999999, -22.059999999999999 },
                    { 189, -10.33, -16.809999999999999, -12.67, -11.07 },
                    { 190, -19.989999999999998, -24.870000000000001, -21.77, -18.59 },
                    { 191, -29.030000000000001, -10.880000000000001, -14.48, -15.5 },
                    { 192, -12.58, -14.199999999999999, -22.77, -13.85 },
                    { 193, -27.079999999999998, -29.140000000000001, -29.399999999999999, -23.010000000000002 },
                    { 194, -30.690000000000001, -24.609999999999999, -10.289999999999999, -19.210000000000001 },
                    { 195, -20.460000000000001, -12.02, -30.350000000000001, -30.899999999999999 },
                    { 196, -19.640000000000001, -18.199999999999999, -15.289999999999999, -21.609999999999999 },
                    { 197, -20.809999999999999, -24.789999999999999, -29.329999999999998, -17.57 },
                    { 198, -20.870000000000001, -15.470000000000001, -30.91, -30.82 },
                    { 177, -14.630000000000001, -15.4, -14.33, -13.94 },
                    { 151, -13.81, -13.710000000000001, -13.56, -14.75 },
                    { 176, -12.630000000000001, -24.41, -25.059999999999999, -12.9 },
                    { 174, -11.789999999999999, -16.190000000000001, -10.94, -24.699999999999999 },
                    { 153, -13.26, -19.649999999999999, -19.600000000000001, -20.0 },
                    { 154, -30.579999999999998, -21.789999999999999, -12.050000000000001, -17.530000000000001 },
                    { 155, -11.75, -16.16, -12.19, -13.289999999999999 },
                    { 156, -22.550000000000001, -30.59, -18.510000000000002, -30.690000000000001 },
                    { 157, -23.969999999999999, -21.98, -16.690000000000001, -12.77 },
                    { 158, -29.579999999999998, -17.73, -16.879999999999999, -21.34 },
                    { 159, -17.829999999999998, -15.32, -17.920000000000002, -23.559999999999999 },
                    { 160, -17.68, -23.579999999999998, -27.530000000000001, -11.789999999999999 }
                });

            migrationBuilder.InsertData(
                table: "Rectangles",
                columns: new[] { "Id", "X1", "X2", "Y1", "Y2" },
                values: new object[,]
                {
                    { 161, -15.58, -15.49, -29.23, -29.460000000000001 },
                    { 162, -23.199999999999999, -14.800000000000001, -18.670000000000002, -28.940000000000001 },
                    { 163, -22.379999999999999, -14.48, -24.57, -23.969999999999999 },
                    { 164, -14.34, -17.219999999999999, -25.489999999999998, -14.220000000000001 },
                    { 165, -26.199999999999999, -13.880000000000001, -21.789999999999999, -21.34 },
                    { 166, -10.85, -21.890000000000001, -14.27, -26.530000000000001 },
                    { 167, -12.779999999999999, -29.260000000000002, -12.17, -25.260000000000002 },
                    { 168, -13.880000000000001, -19.489999999999998, -30.850000000000001, -19.170000000000002 },
                    { 169, -19.640000000000001, -10.4, -28.710000000000001, -17.07 },
                    { 170, -11.359999999999999, -20.059999999999999, -17.48, -19.170000000000002 },
                    { 171, -13.31, -18.760000000000002, -21.390000000000001, -25.100000000000001 },
                    { 172, -24.16, -23.91, -17.0, -10.609999999999999 },
                    { 173, -20.829999999999998, -13.69, -28.359999999999999, -13.800000000000001 },
                    { 175, -11.220000000000001, -12.699999999999999, -26.68, -24.940000000000001 },
                    { 101, -10.9, -25.48, -27.010000000000002, -10.380000000000001 },
                    { 100, -25.59, -23.780000000000001, -24.469999999999999, -12.869999999999999 },
                    { 99, -11.880000000000001, -19.050000000000001, -15.32, -14.58 },
                    { 27, -26.530000000000001, -25.460000000000001, -18.609999999999999, -10.65 },
                    { 28, -15.699999999999999, -27.670000000000002, -27.620000000000001, -28.829999999999998 },
                    { 29, -28.690000000000001, -14.960000000000001, -10.32, -24.27 },
                    { 30, -13.119999999999999, -30.559999999999999, -12.4, -23.859999999999999 },
                    { 31, -18.02, -14.5, -19.449999999999999, -14.300000000000001 },
                    { 32, -16.43, -28.41, -30.5, -15.99 },
                    { 33, -18.789999999999999, -25.870000000000001, -28.789999999999999, -29.469999999999999 },
                    { 34, -26.420000000000002, -16.140000000000001, -24.16, -14.75 },
                    { 35, -23.859999999999999, -28.129999999999999, -28.75, -14.32 },
                    { 36, -11.710000000000001, -24.600000000000001, -29.16, -14.869999999999999 },
                    { 37, -25.43, -24.129999999999999, -17.260000000000002, -24.640000000000001 },
                    { 38, -22.359999999999999, -15.49, -15.640000000000001, -20.329999999999998 },
                    { 39, -10.44, -17.530000000000001, -23.829999999999998, -15.300000000000001 },
                    { 40, -25.219999999999999, -11.83, -24.559999999999999, -29.120000000000001 },
                    { 41, -25.960000000000001, -12.630000000000001, -22.859999999999999, -20.829999999999998 },
                    { 42, -29.890000000000001, -29.149999999999999, -12.41, -22.550000000000001 },
                    { 43, -21.809999999999999, -26.57, -10.42, -15.98 },
                    { 44, -11.81, -29.079999999999998, -22.149999999999999, -24.420000000000002 },
                    { 45, -16.34, -14.58, -19.870000000000001, -23.300000000000001 },
                    { 46, -21.140000000000001, -15.859999999999999, -24.620000000000001, -13.300000000000001 },
                    { 47, -20.23, -18.460000000000001, -29.030000000000001, -18.890000000000001 },
                    { 26, -19.800000000000001, -13.67, -16.120000000000001, -30.989999999999998 },
                    { 48, -23.309999999999999, -18.859999999999999, -20.539999999999999, -22.030000000000001 },
                    { 25, -19.879999999999999, -12.84, -10.390000000000001, -10.85 },
                    { 23, -11.539999999999999, -22.050000000000001, -21.960000000000001, -14.960000000000001 }
                });

            migrationBuilder.InsertData(
                table: "Rectangles",
                columns: new[] { "Id", "X1", "X2", "Y1", "Y2" },
                values: new object[,]
                {
                    { 2, -20.82, -23.699999999999999, -25.75, -15.01 },
                    { 3, -23.52, -29.789999999999999, -14.74, -10.550000000000001 },
                    { 4, -26.870000000000001, -15.32, -12.99, -22.010000000000002 },
                    { 5, -14.630000000000001, -29.09, -29.579999999999998, -22.640000000000001 },
                    { 6, -20.390000000000001, -15.32, -30.390000000000001, -20.129999999999999 },
                    { 7, -10.109999999999999, -12.08, -10.449999999999999, -25.510000000000002 },
                    { 8, -22.170000000000002, -22.34, -26.609999999999999, -12.470000000000001 },
                    { 9, -23.190000000000001, -15.880000000000001, -19.969999999999999, -15.6 },
                    { 10, -19.649999999999999, -16.52, -10.42, -22.02 },
                    { 11, -19.0, -12.720000000000001, -14.02, -13.58 },
                    { 12, -13.130000000000001, -28.16, -24.66, -11.470000000000001 },
                    { 13, -28.379999999999999, -28.890000000000001, -23.559999999999999, -16.280000000000001 },
                    { 14, -18.210000000000001, -19.329999999999998, -14.34, -28.920000000000002 },
                    { 15, -24.640000000000001, -14.69, -17.920000000000002, -18.739999999999998 },
                    { 16, -23.25, -10.24, -23.84, -11.18 },
                    { 17, -13.19, -12.279999999999999, -18.359999999999999, -20.989999999999998 },
                    { 18, -26.350000000000001, -28.390000000000001, -12.359999999999999, -29.100000000000001 },
                    { 19, -28.670000000000002, -17.559999999999999, -13.630000000000001, -17.670000000000002 },
                    { 20, -11.300000000000001, -26.809999999999999, -17.0, -12.960000000000001 },
                    { 21, -18.420000000000002, -29.98, -28.120000000000001, -24.280000000000001 },
                    { 22, -29.780000000000001, -20.329999999999998, -25.25, -13.859999999999999 },
                    { 24, -29.600000000000001, -22.68, -29.77, -18.760000000000002 },
                    { 49, -13.58, -30.629999999999999, -19.359999999999999, -30.09 },
                    { 50, -11.75, -18.329999999999998, -15.98, -27.280000000000001 },
                    { 51, -21.719999999999999, -25.710000000000001, -12.83, -26.800000000000001 },
                    { 78, -14.07, -22.699999999999999, -27.18, -20.129999999999999 },
                    { 79, -16.859999999999999, -14.640000000000001, -16.379999999999999, -28.170000000000002 },
                    { 80, -26.829999999999998, -13.19, -11.34, -18.260000000000002 },
                    { 81, -20.66, -17.98, -12.93, -26.289999999999999 },
                    { 82, -22.59, -13.949999999999999, -13.130000000000001, -18.809999999999999 },
                    { 83, -28.719999999999999, -27.879999999999999, -11.44, -21.84 },
                    { 84, -10.19, -15.06, -28.25, -20.609999999999999 },
                    { 85, -28.440000000000001, -20.41, -28.280000000000001, -12.08 },
                    { 86, -28.629999999999999, -24.579999999999998, -30.969999999999999, -14.73 },
                    { 87, -18.210000000000001, -20.829999999999998, -27.280000000000001, -13.41 },
                    { 88, -27.149999999999999, -26.140000000000001, -28.77, -30.829999999999998 },
                    { 89, -18.829999999999998, -28.890000000000001, -29.32, -10.9 },
                    { 90, -27.77, -17.359999999999999, -18.52, -19.23 },
                    { 91, -27.77, -24.050000000000001, -29.989999999999998, -17.190000000000001 },
                    { 92, -21.27, -15.34, -19.93, -11.800000000000001 },
                    { 93, -17.399999999999999, -26.77, -30.73, -16.420000000000002 },
                    { 94, -15.91, -30.260000000000002, -20.629999999999999, -27.079999999999998 }
                });

            migrationBuilder.InsertData(
                table: "Rectangles",
                columns: new[] { "Id", "X1", "X2", "Y1", "Y2" },
                values: new object[,]
                {
                    { 95, -18.010000000000002, -29.199999999999999, -18.079999999999998, -11.76 },
                    { 96, -17.670000000000002, -30.719999999999999, -22.649999999999999, -12.57 },
                    { 97, -30.109999999999999, -11.609999999999999, -13.0, -12.300000000000001 },
                    { 98, -16.739999999999998, -27.350000000000001, -23.829999999999998, -21.079999999999998 },
                    { 77, -23.18, -30.899999999999999, -11.85, -27.699999999999999 },
                    { 76, -18.879999999999999, -30.710000000000001, -12.65, -10.109999999999999 },
                    { 75, -13.02, -20.18, -16.149999999999999, -18.969999999999999 },
                    { 74, -18.050000000000001, -12.529999999999999, -23.309999999999999, -24.600000000000001 },
                    { 52, -15.08, -30.66, -18.52, -12.359999999999999 },
                    { 53, -26.379999999999999, -30.41, -29.949999999999999, -20.629999999999999 },
                    { 54, -22.960000000000001, -11.26, -17.98, -20.100000000000001 },
                    { 55, -19.010000000000002, -19.559999999999999, -10.6, -21.43 },
                    { 56, -10.119999999999999, -24.52, -30.239999999999998, -12.94 },
                    { 57, -16.030000000000001, -19.390000000000001, -12.41, -12.17 },
                    { 58, -19.710000000000001, -23.059999999999999, -22.670000000000002, -29.010000000000002 },
                    { 59, -29.600000000000001, -23.59, -11.58, -26.43 },
                    { 60, -13.02, -28.82, -29.219999999999999, -20.57 },
                    { 61, -30.940000000000001, -26.670000000000002, -23.5, -23.890000000000001 },
                    { 199, -27.719999999999999, -11.890000000000001, -20.73, -18.699999999999999 },
                    { 62, -19.91, -30.899999999999999, -30.07, -12.32 },
                    { 64, -17.73, -25.559999999999999, -27.16, -28.199999999999999 },
                    { 65, -26.469999999999999, -30.890000000000001, -20.77, -26.690000000000001 },
                    { 66, -28.25, -16.34, -23.649999999999999, -13.32 },
                    { 67, -17.739999999999998, -10.94, -22.030000000000001, -30.370000000000001 },
                    { 68, -30.670000000000002, -22.550000000000001, -17.079999999999998, -21.18 },
                    { 69, -21.34, -21.030000000000001, -21.48, -14.449999999999999 },
                    { 70, -11.02, -16.350000000000001, -24.030000000000001, -16.120000000000001 },
                    { 71, -20.309999999999999, -10.09, -20.52, -20.460000000000001 },
                    { 72, -11.98, -30.48, -21.280000000000001, -14.050000000000001 },
                    { 73, -27.440000000000001, -14.390000000000001, -30.960000000000001, -13.130000000000001 },
                    { 63, -22.66, -30.260000000000002, -21.079999999999998, -23.190000000000001 },
                    { 200, -29.57, -16.600000000000001, -30.829999999999998, -27.629999999999999 }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 11);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 12);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 13);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 14);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 15);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 16);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 17);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 18);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 19);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 20);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 21);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 22);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 23);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 24);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 25);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 26);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 27);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 28);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 29);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 30);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 31);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 32);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 33);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 34);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 35);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 36);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 37);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 38);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 39);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 40);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 41);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 42);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 43);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 44);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 45);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 46);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 47);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 48);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 49);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 50);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 51);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 52);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 53);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 54);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 55);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 56);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 57);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 58);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 59);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 60);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 61);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 62);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 63);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 64);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 65);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 66);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 67);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 68);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 69);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 70);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 71);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 72);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 73);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 74);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 75);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 76);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 77);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 78);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 79);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 80);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 81);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 82);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 83);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 84);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 85);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 86);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 87);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 88);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 89);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 90);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 91);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 92);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 93);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 94);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 95);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 96);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 97);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 98);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 99);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 100);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 101);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 102);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 103);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 104);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 105);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 106);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 107);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 108);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 109);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 110);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 111);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 112);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 113);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 114);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 115);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 116);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 117);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 118);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 119);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 120);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 121);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 122);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 123);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 124);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 125);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 126);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 127);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 128);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 129);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 130);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 131);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 132);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 133);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 134);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 135);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 136);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 137);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 138);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 139);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 140);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 141);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 142);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 143);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 144);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 145);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 146);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 147);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 148);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 149);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 150);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 151);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 152);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 153);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 154);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 155);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 156);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 157);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 158);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 159);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 160);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 161);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 162);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 163);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 164);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 165);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 166);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 167);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 168);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 169);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 170);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 171);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 172);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 173);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 174);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 175);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 176);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 177);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 178);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 179);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 180);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 181);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 182);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 183);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 184);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 185);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 186);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 187);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 188);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 189);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 190);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 191);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 192);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 193);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 194);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 195);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 196);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 197);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 198);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 199);

            migrationBuilder.DeleteData(
                table: "Rectangles",
                keyColumn: "Id",
                keyValue: 200);
        }
    }
}
