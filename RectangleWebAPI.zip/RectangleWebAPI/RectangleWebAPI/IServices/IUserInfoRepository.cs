﻿using RectangleWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RectangleWebAPI.IServices
{
    public interface IUserInfoRepository
    {
        UserInfo Authenticate(string username, string password);
    }
}
