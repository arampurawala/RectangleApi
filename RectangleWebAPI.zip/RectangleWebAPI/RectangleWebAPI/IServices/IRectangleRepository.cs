﻿using RectangleWebAPI.Infrastructure;
using System.Collections.Generic;

namespace RectangleWebAPI.IServices
{
    public interface IRectangleRepository
    {
        List<RectangleList> GetRectangles();
        public List<RectangleList> Search(float x, float y);
    }

}
