﻿using Microsoft.EntityFrameworkCore;
using RectangleWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RectangleWebAPI.Helper
{
    public static class ModelBuilderExtensions
    {
        public static void Seed(this ModelBuilder modelBuilder)
        {
            double minValue = -10.00;
            double maxValue = 10.00;
            var random = new Random();

            for (int i = 1; i <= 200; i++)
            {
                double X1 = Math.Round(((minValue - maxValue - 1) * random.NextDouble() + minValue), 2);
                double X2 = Math.Round(((minValue - maxValue - 1) * random.NextDouble() + minValue), 2);
                double Y1 = Math.Round(((minValue - maxValue - 1) * random.NextDouble() + minValue), 2);
                double Y2 = Math.Round(((minValue - maxValue - 1) * random.NextDouble() + minValue), 2);

                modelBuilder.Entity<RectangleModel>().HasData(
                        new RectangleModel
                        {
                            Id = i,
                            X1 = X1,
                            X2 = X2,
                            Y1 = Y1,
                            Y2 = Y2
                        }
                    );
            }
        }
    }
}
